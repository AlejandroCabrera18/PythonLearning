README
by Alejandro Cabrera

To run the brute force solution, just open it in the same way you would open
any python file. If you would like to change the possible capacity, values, and weights
feel free to do so in the driver portion of the python code 
labeled: "Brute Force Knapsack.py".

For the Branch and Bound solution, I did it in c++ to better implement nodes and Queues,
so open the file "Branch Bound Knapsack.cpp" as you would any other c++ file or copy and paste
the code into this online compiler and it should work fine 
(https://www.onlinegdb.com/online_c++_compiler)
Again, if you would like to change the possible capacity, values, and weights
feel free to do so in the "main" portion of the c++ code 

Sources:
https://www.geeksforgeeks.org/0-1-knapsack-problem-dp-10/
https://www.geeksforgeeks.org/0-1-knapsack-using-branch-and-bound/
https://www.geeksforgeeks.org/implementation-of-0-1-knapsack-using-branch-and-bound/
